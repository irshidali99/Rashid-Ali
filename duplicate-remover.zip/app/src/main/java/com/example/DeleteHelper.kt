package com.example

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import android.util.Log

object DeleteHelper {

    fun getFilePath(context: Context, uri: Uri): String? {
        try {
            val projection = arrayOf(MediaStore.MediaColumns.DATA)
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val dataIdx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                    if (dataIdx != -1) {
                        return cursor.getString(dataIdx)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun physicallyDelete(path: String?): Boolean {
        if (path == null) return false
        val file = File(path)
        if (file.exists()) {
            return try {
                file.delete()
            } catch (e: Exception) {
                false
            }
        }
        return true
    }
}
